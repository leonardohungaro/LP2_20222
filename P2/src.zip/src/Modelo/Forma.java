package Modelo;

public interface Forma {
 	public float calcularArea();
 	public float calcularPerimetro();
}
